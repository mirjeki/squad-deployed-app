﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MBGeneratorUI
{
    public partial class AddSceneryForm : Form
    {
        public string name;
        public string description;
        public int type;

        //ctor for the form populates the combo-box for selecting scenery type, and sets default type
        public AddSceneryForm(Dictionary<string,int> tIndex)
        {
            InitializeComponent();

            foreach (KeyValuePair<string,int> item in tIndex)
            {
                cboType.Items.Add(item.Key);
            }

            //set the default to the first item in the newly populated combobox (type: 'Misc')
            cboType.SelectedIndex = 0;
        }

        //sets public variables to current text (i.e. what the user typed into the boxes) and closes the AddScenery form with the 'OK' result
        private void btnOkay_Click(object sender, EventArgs e)
        {
            name = txtName.Text;
            description = txtDesc.Text;
            type = cboType.SelectedIndex;

            this.DialogResult = DialogResult.OK;

            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
