﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MBGenerator;

namespace MBGeneratorUI
{
    public partial class EditSceneryForm : Form
    {
        public Scenery editedScenery;
        Dictionary<string, int> typeIndex;
        public EditSceneryForm(Scenery selectedScenery, Dictionary<string, int> tIndex)
        {
            InitializeComponent();

            editedScenery = selectedScenery;

            typeIndex = tIndex;
            foreach (KeyValuePair<string, int> item in typeIndex)
            {
                cboType.Items.Add(item.Key);
            }

            txtName.Text = selectedScenery.name;
            txtDesc.Text = selectedScenery.description;
            cboType.SelectedIndex = selectedScenery.type;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnOkay_Click(object sender, EventArgs e)
        {
            editedScenery.name = txtName.Text;
            editedScenery.description = txtDesc.Text;
            editedScenery.type = cboType.SelectedIndex;

            this.DialogResult = DialogResult.OK;

            this.Close();
        }
    }
}
