﻿namespace MBGeneratorUI
{
    partial class MissionForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtMissionDialog = new System.Windows.Forms.RichTextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.tableMap = new System.Windows.Forms.TableLayoutPanel();
            this.btnGenerate = new System.Windows.Forms.Button();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.lblWorldDesc = new System.Windows.Forms.Label();
            this.lblWorldTheme = new System.Windows.Forms.Label();
            this.lblWorldName = new System.Windows.Forms.Label();
            this.lblMission = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtMissionDialog
            // 
            this.txtMissionDialog.Location = new System.Drawing.Point(12, 321);
            this.txtMissionDialog.Name = "txtMissionDialog";
            this.txtMissionDialog.Size = new System.Drawing.Size(608, 67);
            this.txtMissionDialog.TabIndex = 0;
            this.txtMissionDialog.Text = "";
            // 
            // btnSave
            // 
            this.btnSave.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnSave.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(539, 405);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(81, 36);
            this.btnSave.TabIndex = 9;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.BtnSave_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.Location = new System.Drawing.Point(12, 405);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(81, 36);
            this.btnCancel.TabIndex = 10;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // tableMap
            // 
            this.tableMap.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableMap.ColumnCount = 1;
            this.tableMap.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableMap.Location = new System.Drawing.Point(67, 46);
            this.tableMap.Name = "tableMap";
            this.tableMap.RowCount = 1;
            this.tableMap.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableMap.Size = new System.Drawing.Size(500, 250);
            this.tableMap.TabIndex = 11;
            // 
            // btnGenerate
            // 
            this.btnGenerate.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenerate.Location = new System.Drawing.Point(278, 405);
            this.btnGenerate.Name = "btnGenerate";
            this.btnGenerate.Size = new System.Drawing.Size(81, 36);
            this.btnGenerate.TabIndex = 12;
            this.btnGenerate.Text = "Generate";
            this.btnGenerate.UseVisualStyleBackColor = true;
            this.btnGenerate.Click += new System.EventHandler(this.BtnGenerate_Click);
            // 
            // lblWorldDesc
            // 
            this.lblWorldDesc.AutoSize = true;
            this.lblWorldDesc.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWorldDesc.Location = new System.Drawing.Point(236, 29);
            this.lblWorldDesc.Name = "lblWorldDesc";
            this.lblWorldDesc.Size = new System.Drawing.Size(86, 14);
            this.lblWorldDesc.TabIndex = 26;
            this.lblWorldDesc.Text = "No description";
            // 
            // lblWorldTheme
            // 
            this.lblWorldTheme.AutoSize = true;
            this.lblWorldTheme.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWorldTheme.Location = new System.Drawing.Point(323, 304);
            this.lblWorldTheme.Name = "lblWorldTheme";
            this.lblWorldTheme.Size = new System.Drawing.Size(32, 14);
            this.lblWorldTheme.TabIndex = 24;
            this.lblWorldTheme.Text = "Misc";
            // 
            // lblWorldName
            // 
            this.lblWorldName.AutoSize = true;
            this.lblWorldName.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWorldName.Location = new System.Drawing.Point(275, 9);
            this.lblWorldName.Name = "lblWorldName";
            this.lblWorldName.Size = new System.Drawing.Size(58, 14);
            this.lblWorldName.TabIndex = 23;
            this.lblWorldName.Text = "Unknown";
            // 
            // lblMission
            // 
            this.lblMission.AutoSize = true;
            this.lblMission.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMission.Location = new System.Drawing.Point(236, 304);
            this.lblMission.Name = "lblMission";
            this.lblMission.Size = new System.Drawing.Size(81, 14);
            this.lblMission.TabIndex = 27;
            this.lblMission.Text = "Mission Type:";
            // 
            // MissionForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(632, 453);
            this.Controls.Add(this.lblMission);
            this.Controls.Add(this.lblWorldDesc);
            this.Controls.Add(this.lblWorldTheme);
            this.Controls.Add(this.lblWorldName);
            this.Controls.Add(this.btnGenerate);
            this.Controls.Add(this.tableMap);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.txtMissionDialog);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "MissionForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Mission";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox txtMissionDialog;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.TableLayoutPanel tableMap;
        private System.Windows.Forms.Button btnGenerate;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.Label lblWorldDesc;
        private System.Windows.Forms.Label lblWorldTheme;
        private System.Windows.Forms.Label lblWorldName;
        private System.Windows.Forms.Label lblMission;
    }
}