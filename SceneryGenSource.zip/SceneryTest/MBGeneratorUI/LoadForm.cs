﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MBGeneratorUI
{
    public partial class LoadForm : Form
    {
        string[] saveFiles;
        public string selectedFile;
        public LoadForm(string[] saveFiles)
        {
            InitializeComponent();
            this.saveFiles = saveFiles;
            lstSaveFiles.DataSource = saveFiles;
        }

        private void btnOkay_Click(object sender, EventArgs e)
        {
            if (lstSaveFiles.SelectedIndex < 0)
            {
                MessageBox.Show("Please select a file to load!", "No save file selected");
            }
            else
            {
                selectedFile = saveFiles[lstSaveFiles.SelectedIndex];

                this.Close();
            }
        }
    }
}
