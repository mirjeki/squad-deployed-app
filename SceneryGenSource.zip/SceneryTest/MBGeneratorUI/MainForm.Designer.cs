﻿namespace MBGeneratorUI
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExit = new System.Windows.Forms.Button();
            this.btnGenerate = new System.Windows.Forms.Button();
            this.addScenery = new System.Windows.Forms.Button();
            this.editScenery = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnLoad = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblWorldName = new System.Windows.Forms.Label();
            this.lblWorldTheme = new System.Windows.Forms.Label();
            this.btnEdit = new System.Windows.Forms.Button();
            this.lstScenery = new System.Windows.Forms.ListView();
            this.SceneryName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SceneryDescription = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.radLargeWorld = new System.Windows.Forms.RadioButton();
            this.radMediumWorld = new System.Windows.Forms.RadioButton();
            this.radSmallWorld = new System.Windows.Forms.RadioButton();
            this.removeScenery = new System.Windows.Forms.Button();
            this.lblWorldDesc = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(545, 405);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 36);
            this.btnExit.TabIndex = 7;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnGenerate
            // 
            this.btnGenerate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenerate.Location = new System.Drawing.Point(12, 405);
            this.btnGenerate.Name = "btnGenerate";
            this.btnGenerate.Size = new System.Drawing.Size(110, 36);
            this.btnGenerate.TabIndex = 4;
            this.btnGenerate.Text = "Generate";
            this.btnGenerate.UseVisualStyleBackColor = true;
            this.btnGenerate.Click += new System.EventHandler(this.BtnGenerate_Click);
            // 
            // addScenery
            // 
            this.addScenery.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addScenery.Location = new System.Drawing.Point(545, 116);
            this.addScenery.Name = "addScenery";
            this.addScenery.Size = new System.Drawing.Size(75, 44);
            this.addScenery.TabIndex = 2;
            this.addScenery.Text = "Add Scenery";
            this.addScenery.UseVisualStyleBackColor = true;
            this.addScenery.Click += new System.EventHandler(this.BtnAddScenery_Click);
            // 
            // editScenery
            // 
            this.editScenery.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.editScenery.Location = new System.Drawing.Point(545, 166);
            this.editScenery.Name = "editScenery";
            this.editScenery.Size = new System.Drawing.Size(75, 44);
            this.editScenery.TabIndex = 3;
            this.editScenery.Text = "Edit Scenery";
            this.editScenery.UseVisualStyleBackColor = true;
            this.editScenery.Click += new System.EventHandler(this.BtnEditScenery_Click);
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(353, 405);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(81, 36);
            this.btnSave.TabIndex = 5;
            this.btnSave.Text = "Save World";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.BtnSave_Click);
            // 
            // btnLoad
            // 
            this.btnLoad.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoad.Location = new System.Drawing.Point(440, 405);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(90, 36);
            this.btnLoad.TabIndex = 6;
            this.btnLoad.Text = "Load World";
            this.btnLoad.UseVisualStyleBackColor = true;
            this.btnLoad.Click += new System.EventHandler(this.BtnLoad_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 100);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 14);
            this.label1.TabIndex = 7;
            this.label1.Text = "Available Scenery";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 14);
            this.label2.TabIndex = 8;
            this.label2.Text = "World Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 42);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 14);
            this.label3.TabIndex = 9;
            this.label3.Text = "World Theme:";
            // 
            // lblWorldName
            // 
            this.lblWorldName.AutoSize = true;
            this.lblWorldName.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWorldName.Location = new System.Drawing.Point(92, 6);
            this.lblWorldName.Name = "lblWorldName";
            this.lblWorldName.Size = new System.Drawing.Size(58, 14);
            this.lblWorldName.TabIndex = 10;
            this.lblWorldName.Text = "Unknown";
            // 
            // lblWorldTheme
            // 
            this.lblWorldTheme.AutoSize = true;
            this.lblWorldTheme.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWorldTheme.Location = new System.Drawing.Point(92, 42);
            this.lblWorldTheme.Name = "lblWorldTheme";
            this.lblWorldTheme.Size = new System.Drawing.Size(32, 14);
            this.lblWorldTheme.TabIndex = 11;
            this.lblWorldTheme.Text = "Misc";
            // 
            // btnEdit
            // 
            this.btnEdit.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEdit.Location = new System.Drawing.Point(12, 61);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(110, 36);
            this.btnEdit.TabIndex = 1;
            this.btnEdit.Text = "Edit World";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // lstScenery
            // 
            this.lstScenery.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.SceneryName,
            this.SceneryDescription});
            this.lstScenery.FullRowSelect = true;
            this.lstScenery.Location = new System.Drawing.Point(12, 117);
            this.lstScenery.MultiSelect = false;
            this.lstScenery.Name = "lstScenery";
            this.lstScenery.Size = new System.Drawing.Size(518, 263);
            this.lstScenery.TabIndex = 12;
            this.lstScenery.TabStop = false;
            this.lstScenery.UseCompatibleStateImageBehavior = false;
            this.lstScenery.View = System.Windows.Forms.View.Details;
            // 
            // SceneryName
            // 
            this.SceneryName.Text = "Name";
            this.SceneryName.Width = 168;
            // 
            // SceneryDescription
            // 
            this.SceneryDescription.Text = "Description";
            this.SceneryDescription.Width = 350;
            // 
            // radLargeWorld
            // 
            this.radLargeWorld.AutoSize = true;
            this.radLargeWorld.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLargeWorld.Location = new System.Drawing.Point(128, 430);
            this.radLargeWorld.Name = "radLargeWorld";
            this.radLargeWorld.Size = new System.Drawing.Size(121, 19);
            this.radLargeWorld.TabIndex = 17;
            this.radLargeWorld.Text = "4x4 - Large World";
            this.radLargeWorld.UseVisualStyleBackColor = true;
            // 
            // radMediumWorld
            // 
            this.radMediumWorld.AutoSize = true;
            this.radMediumWorld.Font = new System.Drawing.Font("Calibri", 9.75F);
            this.radMediumWorld.Location = new System.Drawing.Point(128, 407);
            this.radMediumWorld.Name = "radMediumWorld";
            this.radMediumWorld.Size = new System.Drawing.Size(137, 19);
            this.radMediumWorld.TabIndex = 16;
            this.radMediumWorld.Text = "3x3 - Medium World";
            this.radMediumWorld.UseVisualStyleBackColor = true;
            // 
            // radSmallWorld
            // 
            this.radSmallWorld.AutoSize = true;
            this.radSmallWorld.Checked = true;
            this.radSmallWorld.Font = new System.Drawing.Font("Calibri", 9.75F);
            this.radSmallWorld.Location = new System.Drawing.Point(128, 386);
            this.radSmallWorld.Name = "radSmallWorld";
            this.radSmallWorld.Size = new System.Drawing.Size(123, 19);
            this.radSmallWorld.TabIndex = 15;
            this.radSmallWorld.TabStop = true;
            this.radSmallWorld.Text = "2x2 - Small World";
            this.radSmallWorld.UseVisualStyleBackColor = true;
            // 
            // removeScenery
            // 
            this.removeScenery.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.removeScenery.Location = new System.Drawing.Point(545, 216);
            this.removeScenery.Name = "removeScenery";
            this.removeScenery.Size = new System.Drawing.Size(75, 44);
            this.removeScenery.TabIndex = 18;
            this.removeScenery.Text = "Remove Scenery";
            this.removeScenery.UseVisualStyleBackColor = true;
            this.removeScenery.Click += new System.EventHandler(this.BtnRemoveScenery_Click);
            // 
            // lblWorldDesc
            // 
            this.lblWorldDesc.AutoSize = true;
            this.lblWorldDesc.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWorldDesc.Location = new System.Drawing.Point(92, 24);
            this.lblWorldDesc.Name = "lblWorldDesc";
            this.lblWorldDesc.Size = new System.Drawing.Size(86, 14);
            this.lblWorldDesc.TabIndex = 20;
            this.lblWorldDesc.Text = "No description";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 24);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 14);
            this.label5.TabIndex = 19;
            this.label5.Text = "World Desc.:";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(632, 453);
            this.Controls.Add(this.lblWorldDesc);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.removeScenery);
            this.Controls.Add(this.radLargeWorld);
            this.Controls.Add(this.radMediumWorld);
            this.Controls.Add(this.radSmallWorld);
            this.Controls.Add(this.lstScenery);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.lblWorldTheme);
            this.Controls.Add(this.lblWorldName);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnLoad);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.editScenery);
            this.Controls.Add(this.addScenery);
            this.Controls.Add(this.btnGenerate);
            this.Controls.Add(this.btnExit);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MBGenerator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnGenerate;
        private System.Windows.Forms.Button addScenery;
        private System.Windows.Forms.Button editScenery;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnLoad;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblWorldName;
        private System.Windows.Forms.Label lblWorldTheme;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.ListView lstScenery;
        private System.Windows.Forms.ColumnHeader SceneryName;
        private System.Windows.Forms.ColumnHeader SceneryDescription;
        private System.Windows.Forms.RadioButton radLargeWorld;
        private System.Windows.Forms.RadioButton radMediumWorld;
        private System.Windows.Forms.RadioButton radSmallWorld;
        private System.Windows.Forms.Button removeScenery;
        private System.Windows.Forms.Label lblWorldDesc;
        private System.Windows.Forms.Label label5;
    }
}

