﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MBGenerator;

namespace MBGeneratorUI
{
    public partial class EditWorldNameForm : Form
    {
        World newWorld;
        public EditWorldNameForm(World world, Dictionary<string, int> themeIndex)
        {
            InitializeComponent();
            newWorld = world;
            txtNewName.Text = newWorld.name;
            txtNewDesc.Text = newWorld.desc;

            foreach (KeyValuePair<string, int> item in themeIndex)
            {
                cboTheme.Items.Add(item.Key);
            }

            cboTheme.SelectedItem = newWorld.theme;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnOkay_Click(object sender, EventArgs e)
        {
            newWorld.name = txtNewName.Text;
            newWorld.desc = txtNewDesc.Text;
            newWorld.theme = cboTheme.Text;

            this.DialogResult = DialogResult.OK;

            this.Close();
        }
    }
}
