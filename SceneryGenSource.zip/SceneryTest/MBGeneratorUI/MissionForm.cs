﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MBGenerator;
using System.IO;
using System.Xml;
using System.Xml.Linq;
using System.Xml.XPath;
using System.Text.RegularExpressions;

namespace MBGeneratorUI
{
    public partial class MissionForm : Form
    {
        World world;
        int worldSize;
        string missionOutput;
        List<string> sceneryNames = new List<string>();
        RichTextBox[,] labels;
        Random ran;
        int columnCount;
        int rowCount;
        public string savePath = $"{System.AppDomain.CurrentDomain.BaseDirectory}" + "\\SavedMissions\\";

        public string objectivesPath = $"{System.AppDomain.CurrentDomain.BaseDirectory}" + "\\Objectives\\";
        public MissionForm(World world, int worldSize)
        {
            InitializeComponent();
            ran = new Random();
            this.world = world;
            this.worldSize = worldSize;
            lblWorldName.Text = this.world.name;
            lblWorldDesc.Text = this.world.desc;
            lblWorldTheme.Text = this.world.theme;
            tableMap.RowStyles.RemoveAt(0);
            tableMap.ColumnStyles.RemoveAt(0);
            GenerateMission();
            columnCount = tableMap.ColumnCount - 1;
            rowCount = tableMap.RowCount - 1;
            labels = new RichTextBox[tableMap.ColumnCount, tableMap.RowCount];

            MapSetup();


        }

        private void MapSetup()
        {
            tableMap.Controls.Clear();

            for (int x = 0; x <= columnCount; x++)
            {
                for (int y = 0; y <= rowCount; y++)
                {
                    if (labels[x, y] == null)
                    {
                        labels[x, y] = new RichTextBox();
                        labels[x, y].BorderStyle = BorderStyle.None;
                        labels[x, y].Multiline = true;
                        labels[x, y].BackColor = Color.FromName("Control");
                    }
                    labels[x, y].Text = "[Cell]";
                }
            }
            SceneryAssigner();

            for (int x = 0; x <= columnCount; x++)
            {
                for (int y = 0; y <= rowCount; y++)
                {
                    tableMap.Controls.Add(labels[x, y], x, y);
                }
            }
        }

        private void SceneryAssigner()
        {
            foreach (string scenery in sceneryNames)
            {
                bool succeeded = false;
                while (!succeeded)
                {
                    int chosenX = ran.Next(0, tableMap.ColumnCount);
                    int chosenY = ran.Next(0, tableMap.RowCount);

                    if (labels[chosenX, chosenY].Text == "[Cell]")
                    {
                        labels[chosenX, chosenY].Text = $"{scenery}";
                        succeeded = true;
                    }
                }
            }
        }

        private void GenerateMission()
        {
            txtMissionDialog.Clear();
            missionOutput = "";
            sceneryNames.Clear();

            switch (worldSize)
            {
                case 2:
                    tableMap.ColumnCount = 2;
                    tableMap.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
                    tableMap.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));

                    tableMap.RowCount = 2;
                    tableMap.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
                    tableMap.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));

                    world.cellCount = 4;
                    world.GenerateWorld();
                    break;

                case 3:
                    tableMap.ColumnCount = 3;
                    tableMap.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.3F));
                    tableMap.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.3F));
                    tableMap.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.3F));

                    tableMap.RowCount = 3;
                    tableMap.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.3F));
                    tableMap.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.3F));
                    tableMap.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.3F));

                    world.cellCount = 9;
                    world.GenerateWorld();
                    break;

                case 4:
                    tableMap.ColumnCount = 4;
                    tableMap.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
                    tableMap.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
                    tableMap.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
                    tableMap.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));

                    tableMap.RowCount = 4;
                    tableMap.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
                    tableMap.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
                    tableMap.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
                    tableMap.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));

                    world.cellCount = 16;
                    world.GenerateWorld();
                    break;

                default:
                    break;
            }



            missionOutput += "Mission Objectives:\n\n";
            int sceneryCount = 0;

            List<string> compatibleObjectivesList = new List<string>();


            foreach (Scenery scenery in world.currentWorld)
            {
                sceneryCount++;

                sceneryNames.Add(scenery.name);
            }

            var missionDoc = XDocument.Load(objectivesPath + "MissionObjectives" + world.theme + ".xml");

            foreach (Scenery scenery in world.currentWorld)
            {
                int sceneryType = scenery.type;

                if (sceneryType != 0)
                {
                    XElement node = missionDoc.XPathSelectElement($"//MissionObjectives/Theme/SceneryType[{sceneryType}]");

                    IEnumerable<XElement> nodeList = node.Descendants();

                    foreach (XElement objectiveElement in nodeList)
                    {
                        if (objectiveElement.Value != null)
                        {
                            string result = objectiveElement.Value.Trim();
                            compatibleObjectivesList.Add(result);
                        }
                    }
                }
            }

            Random random = new Random();

            if (compatibleObjectivesList.Count != 0)
            {
                string objectiveText = compatibleObjectivesList[random.Next(0, (compatibleObjectivesList.Count - 1))];

                missionOutput += $"{objectiveText}";
            }

            else
            {
                missionOutput += $"Destroy the opponent.";
            }


            txtMissionDialog.Text = missionOutput;
        }

        private void BtnGenerate_Click(object sender, EventArgs e)
        {
            GenerateMission();
            MapSetup();
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Text File|*.txt";
            saveFileDialog.Title = "Save your mission";
            saveFileDialog.OverwritePrompt = true;
            saveFileDialog.InitialDirectory = savePath;
            saveFileDialog.FileName = this.world.name + " Mission";

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                string fileName = saveFileDialog.FileName;
                if (File.Exists(fileName))
                {
                    File.Delete(fileName);
                }
                WriteMissionToTxt(fileName);
            }
        }

        private void WriteMissionToTxt(string fileName)
        {
            string divider = "***";

            for (int i = 0; i < tableMap.ColumnCount; i++)
            {
                for (int j = 0; j < tableMap.RowCount; j++)
                {
                    File.AppendAllText(fileName, "|");
                    File.AppendAllText(fileName, $"{labels[i, j].Text,-25}");
                }
                File.AppendAllText(fileName, "|");
                File.AppendAllText(fileName, Environment.NewLine);
                File.AppendAllText(fileName, $"{divider,-26}");
                File.AppendAllText(fileName, $"{divider,1}");
                File.AppendAllText(fileName, Environment.NewLine);
                File.AppendAllText(fileName, Environment.NewLine);
            }
            File.AppendAllText(fileName, missionOutput.Substring(0, 19));
            File.AppendAllText(fileName, Environment.NewLine);
            File.AppendAllText(fileName, Environment.NewLine);

            int charCount = 0;
            string formattedMissionOutput = missionOutput.Replace("\t", " ");
            while (formattedMissionOutput.IndexOf("  ") > 0)
            {
                formattedMissionOutput = formattedMissionOutput.Replace("  ", " ");
            }

            for (int i = 19; i < formattedMissionOutput.Length; i++)
            {
                File.AppendAllText(fileName, formattedMissionOutput.Substring(i, 1));
                if (charCount >= 50
                    && (formattedMissionOutput.Substring(i, 1)) == " ")
                {
                    File.AppendAllText(fileName, Environment.NewLine);
                    charCount = 0;
                }
                charCount++;
            }
        }
    }
}
