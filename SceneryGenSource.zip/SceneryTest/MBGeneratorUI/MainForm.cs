﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MBGenerator;
using System.IO;
using System.Xml;
using System.Xml.Linq;

namespace MBGeneratorUI
{
    public partial class MainForm : Form
    {
        private World world;
        private List<string> missionObjectives = new List<string>();
        private string savePath = $"{System.AppDomain.CurrentDomain.BaseDirectory}" + "\\Saves\\";
        private Dictionary<string, int> typeIndex = new Dictionary<string, int>();
        private Dictionary<string, int> themeIndex = new Dictionary<string, int>();
        
        public MainForm()
        {
            InitializeComponent();
            typeIndex.Add("Misc", 0);
            typeIndex.Add("River", 1);
            typeIndex.Add("Forest", 2);
            typeIndex.Add("Building", 3);
            typeIndex.Add("Fortification", 4);
            typeIndex.Add("Mere", 5);
            typeIndex.Add("Hill", 6);
            typeIndex.Add("Artefact", 7);
            typeIndex.Add("Ruin", 8);

            themeIndex.Add("Misc", 0);
            themeIndex.Add("Gothic", 1);
            themeIndex.Add("Fantasy", 2);
            
            //creates a 'saves' directory if none currently exists
            DirectoryInfo di = Directory.CreateDirectory(savePath);

            //create new world instance. This contains a list of all the scenery objects available
            //label text for world details makes up the parameters of the world. These can be edited later via the EditWorldNameForm
            world = new World(lblWorldName.Text, lblWorldDesc.Text, lblWorldTheme.Text);
        }

        //opens a form to edit the world details, such as world name, description and chosen theme (Default is 'Misc')
        private void btnEdit_Click(object sender, EventArgs e)
        {
            EditWorldNameForm editForm = new EditWorldNameForm(world, themeIndex);

            if (editForm.ShowDialog() == DialogResult.OK)
            {
                UpdateForm();
            }
        }


        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        public void UpdateForm()
        {
            lstScenery.Items.Clear();

            //populate the ListView with all scenery objects available in world
            foreach (Scenery scenery in world.sceneryObjects)
            {
                //listed as a string 'name', and a sub-item of string 'description'
                lstScenery.Items.Add(scenery.name).SubItems.Add(scenery.description);
            }

            //update the worldname, description and theme to world's current values
            lblWorldName.Text = this.world.name;
            lblWorldDesc.Text = this.world.desc;
            lblWorldTheme.Text = this.world.theme;
        }

        private void BtnAddScenery_Click(object sender, EventArgs e)
        {
            AddSceneryForm addForm = new AddSceneryForm(typeIndex);

            //check if the AddScenery form resulted in an 'OK' 
            //if so, create a new Scenery object using the values the form held at the moment the form's 'Okay' button was clicked
            if (addForm.ShowDialog() == DialogResult.OK)
            {
                Scenery newScenery = new Scenery(addForm.name, addForm.description, addForm.type);
                //add the new scenery object to the world
                world.ObjectAdder(newScenery);
                UpdateForm();
            }
        }

        private void BtnRemoveScenery_Click(object sender, EventArgs e)
        {
            //ensures an item in the list is selected. If not, then a messagebox will prompt the user to select one.
            //a try/catch could be used instead if desired
            if (lstScenery.FocusedItem == null)
            {
                MessageBox.Show("Please select an object to remove!", "No object selected");
            }
            //as SelectedIndices can only be a number selected or null, this (hopefully) shouldn't fail
            //no tests for edge cases have been made. 
            //TODO: test for SelectedIndices outside of range of list, catch exceptions as appropriate
            else
            {
                world.sceneryObjects.RemoveAt(lstScenery.SelectedIndices[0]);
                UpdateForm();
            }
        }

        //this will populate the map with a random number of scenery objects as appropriate for the user's world size 
        //NOTE: in miniature wargames, typically battles will take place on boards of 2x2 / 3x3 / 4x4 feet, the world sizes available reflect these
        //Planned feature: Users can choose their worldsize in digits rather than radio buttons (i.e. user can choose for a 1x4 board)
        private void BtnGenerate_Click(object sender, EventArgs e)
        {
            //checks if the world has at least 1 scenery object. If not, prompt user that generation cannot process without any scenery
            if (world.sceneryObjects.Count > 0)
            {
                int worldSize = 0;

                if (radSmallWorld.Checked)
                {
                    worldSize = 2;
                }
                if (radMediumWorld.Checked)
                {
                    worldSize = 3;
                }
                if (radLargeWorld.Checked)
                {
                    worldSize = 4;
                }

                missionObjectives = world.missionObjectives;

                MissionForm missionForm = new MissionForm(world, worldSize);

                missionForm.ShowDialog();
            }
            else
            {
                MessageBox.Show("You must have at least one item of scenery to generate a mission.", "Empty World");
            }


        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "XML File|*.xml";
            saveFileDialog.Title = "Save your world";
            saveFileDialog.OverwritePrompt = true;
            saveFileDialog.InitialDirectory = savePath;
            saveFileDialog.FileName = this.world.name;

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                string fileName = saveFileDialog.FileName;
                if (File.Exists(fileName))
                {
                    File.Delete(fileName);
                }

                this.world.Save(fileName);
            }
        }

        private void BtnLoad_Click(object sender, EventArgs e)
        {
            string[] saveFiles = Directory.GetFiles(savePath, "*.xml")
                .Select(Path.GetFileName)
                .ToArray();

            LoadForm loadForm = new LoadForm(saveFiles);

            if (loadForm.ShowDialog() == DialogResult.OK)
            {
                string filename = $"{savePath + loadForm.selectedFile}";

                this.world = World.Load(filename);

                UpdateForm();
            }
        }

        private void BtnEditScenery_Click(object sender, EventArgs e)
        {
            if (lstScenery.FocusedItem == null)
            {
                MessageBox.Show("Please select an object to edit!", "No object selected");
            }
            else
            {
                int selectedIndex = lstScenery.SelectedIndices[0];
                EditSceneryForm editForm = new EditSceneryForm(world.sceneryObjects[selectedIndex], typeIndex);

                if (editForm.ShowDialog() == DialogResult.OK)
                {
                    UpdateForm();
                }
            }
            
        }
    }
}

