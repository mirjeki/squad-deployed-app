﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBGenerator
{
    public class Scenery
    {
        public string name;
        public string description;
        public int type;
        public string imageFile;

        public Scenery()
        {
            name = "Random Scenery";
            description = "No description";
            imageFile = @"images\default.png";
        }
        public Scenery(string nm, string desc, int t)
        {
            name = nm;
            description = desc;
            type = t;
            imageFile = @"images\" + name + ".png";
        }

        public override string ToString()
        {
            return $"{name}\t{description}";
        }
    }
}
