﻿namespace MBGenerator
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Xml.Serialization;

    public class World
    {
        Random random = new Random();
        public string name;
        public string desc;
        public string theme;
        public int cellCount;

        public List<Scenery> sceneryObjects = new List<Scenery>();
        public List<Scenery> availableScenery = new List<Scenery>();
        public List<Scenery> currentWorld = new List<Scenery>();
        public List<string> sceneryTypes = new List<string>();

        public List<string> missionObjectives = new List<string>();

        /// <summary>
        /// Required for Serialization
        /// </summary>
        public World()
        {
        }

        public World(string name, string desc, string theme)
        {
            this.name = name;
            this.desc = desc;
            this.theme = theme;
        }

        //as all world information is held in the 'world' class (world details + all scenery objects are held in a list in 'world'), the data can be easily saved
        //save process uses serialisation to write the world instance into an xml file.
        public void Save(string filename)
        {
            using (StreamWriter writer = new StreamWriter(filename))
            {
                XmlSerializer serializer = new XmlSerializer(this.GetType());
                serializer.Serialize(writer, this);
                writer.Flush();
            }
        }

        //opens file, deserialises it as object desired (World)
        public static World Load(string filename)
        {
            using (FileStream stream = File.OpenRead(filename))
            {
                XmlSerializer serializer = new XmlSerializer(typeof(World));
                return serializer.Deserialize(stream) as World;
            }
        }

        public void ObjectAdder(Scenery scenery)
        {
            sceneryObjects.Add(scenery);
        }

        //clears the currentWorld of objects. The currentWorld is temporary and made up of random numbers of available scenery objects
        public void ClearWorld()
        {
            currentWorld.Clear();
        }

        //Planned feature: Add button to MainForm allowing user to clear entire world
        //public void ClearAllScenery()

        //generates a random list of scenery objects to populate map with (currentWorld), based on a random number (more below)
        public void GenerateWorld()
        {
            //user can choose to Generate while looking at a map to quickly cycle through different setups, the map needs to be cleared first 
            ClearWorld();

            //create a new list identical to the list of objects the user has made
            availableScenery = sceneryObjects.ConvertAll(scenery => new Scenery(scenery.name, scenery.description, scenery.type));
            
            //if the amount of available scenery is greater than the amount of cells to fill on the map
            if (availableScenery.Count() >= cellCount)
            {
                //choose an amount of scenery items to populate the map with (between half the total number of cells and up to the total number of cells)
                int itemsToAdd = random.Next((cellCount / 2), (cellCount));

                //iterate through the list, adding a random scenery item to the currentWorld from the availableScenery list, then removing that very same item from availableScenery
                //this produces the effect of having random items in the currentWorld (the map the user will see), while also ensuring that they can't end up with more scenery items of the same type than they have available
                for (int i = 0; i <= itemsToAdd; i++)
                {
                    int randomIndex = random.Next(0, availableScenery.Count());
                    currentWorld.Add(availableScenery[randomIndex]);
                    availableScenery.Remove(availableScenery[randomIndex]);
                }
            }

            else
            {
                //if the availableScenery list is less than the number of Cells needing to be populated, then use ALL available scenery (in a random order)
                int itemsToAdd = random.Next(0, availableScenery.Count());
                for (int i = 0; i <= itemsToAdd; i++)
                {
                    int randomIndex = random.Next(0, availableScenery.Count());
                    currentWorld.Add(availableScenery[randomIndex]);
                    availableScenery.Remove(availableScenery[randomIndex]);
                }
            }
        }
    }
}
